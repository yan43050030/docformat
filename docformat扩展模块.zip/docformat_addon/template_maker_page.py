# -*- coding: utf-8 -*-
"""
============================================================================
模块二：模板制作页 (TemplateMakerPage) —— 历史件转模板
============================================================================

【用途】
把一份"已脱密的历史公文"快速转成可复用模板。
核心是"机器抽结构 + 人工点选挖空"——这是这个功能唯一现实可行的方式：

  · 机器能自动做的：切分标题/正文段落/落款、识别"一、""（一）"层级。
  · 机器【做不到】的：判断哪些内容是"固定套话"（该保留）、哪些是
    "案件变量"（该挖成 {{占位符}}）。例如"鉴于犯罪嫌疑人张某某涉嫌受贿"，
    "鉴于…涉嫌…"是套话该留，"张某某""受贿"是变量该挖。这个判断依赖
    业务经验，机器猜会挖错，反而更费事。所以由你【框选文字→点按钮→命名】
    来挖空，一份历史件两三分钟就能转成模板。

【工作流】
  1. 载入脱密历史件（.docx 或直接粘贴纯文本）
  2. 软件自动切分结构，显示在可编辑文本区
  3. 你在文本区选中要变成变量的文字 → 点"挖空为占位符" → 输入字段名
     （软件自动把该文字所有相同出现一并替换，如所有"张某某"→{{嫌疑人}}）
  4. 固定套话保持不动
  5. 点"保存为模板" → 生成符合模块一格式的 .md，存入模板库

【集成方式 —— 请把下面几点转告合并用的大模型】

1) 作为侧边栏"第六个模式"，标签名建议"模板制作"。注册方式同模块一。
   >>> TODO(合并时): 仿照现有页面注册方式加入主窗口侧边栏。

2) 读取 .docx：本模块用 python-docx 读段落纯文本。软件已有 .doc/.wps→docx
   的转换链（Windows 走 COM、Linux 走 LibreOffice）。
   >>> TODO(合并时): 若要支持 .doc/.wps 输入，先调用软件现有的 converter
       把文件转成 .docx，再交给本页的 load_docx()。

3) 结构识别：本模块用简单规则（标题=首个非空行、"一、"/"（一）"层级）。
   软件的 analyzer 有更强的 11 类要素识别（密级/发文字号/署名/日期等）。
   >>> TODO(合并时，可选增强): 可用现有 analyzer 的段落类型标注结果替换
       本模块的 _rough_split()，让层级/落款识别更准。接口对不上时，
       保留本模块的规则版即可正常工作。

4) 模板保存目录：与模块一共用 TEMPLATE_DIR。
   >>> TODO(合并时): 改成软件实际模板目录，与模块一保持一致。

5) 依赖：PyQt5；读取 docx 用 python-docx（软件已依赖）。

【重要业务提醒（请你本人确认，非技术问题）】
把真实案件文书转成通用模板并留存在单机，是否符合单位对案件材料留存、
定密的内部规定，请先按单位要求确认后再批量使用。
============================================================================
"""
import os
import re

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QTextEdit, QLineEdit, QFileDialog, QMessageBox, QInputDialog, QListWidget
)
from PyQt5.QtGui import QTextCursor
from PyQt5.QtCore import Qt

# >>> TODO(合并时): 与模块一保持一致，改成软件实际模板目录
TEMPLATE_DIR = os.path.join(os.path.dirname(__file__), "templates")


class TemplateMakerPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.field_names = []   # 已挖空的字段名，供保存时提示
        self._build_ui()

    def _build_ui(self):
        outer = QVBoxLayout(self)

        # 顶部工具条
        top = QHBoxLayout()
        self.btn_open = QPushButton("载入历史件(.docx)")
        self.btn_open.clicked.connect(self._on_open)
        self.btn_paste_hint = QLabel("或直接把脱密正文粘贴到下方文本框")
        top.addWidget(self.btn_open)
        top.addWidget(self.btn_paste_hint)
        top.addStretch()
        outer.addLayout(top)

        outer.addWidget(QLabel("正文（选中要变成变量的文字，点下方按钮挖空）"))
        self.editor = QTextEdit()
        self.editor.setAcceptRichText(False)
        outer.addWidget(self.editor)

        # 挖空工具条
        mid = QHBoxLayout()
        self.btn_hole = QPushButton("① 挖空选中文字为占位符")
        self.btn_hole.clicked.connect(self._on_make_hole)
        self.btn_title = QPushButton("② 标记选中行为标题")
        self.btn_title.clicked.connect(self._on_mark_title)
        mid.addWidget(self.btn_hole)
        mid.addWidget(self.btn_title)
        mid.addStretch()
        outer.addLayout(mid)

        # 落款
        foot = QHBoxLayout()
        foot.addWidget(QLabel("落款单位:"))
        self.sender_edit = QLineEdit()
        self.sender_edit.setPlaceholderText("可留占位符，如 {{办案单位}}")
        foot.addWidget(self.sender_edit)
        foot.addWidget(QLabel("落款日期:"))
        self.date_edit = QLineEdit()
        self.date_edit.setPlaceholderText("如 {{落款日期}}")
        foot.addWidget(self.date_edit)
        outer.addLayout(foot)

        # 保存
        bottom = QHBoxLayout()
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("模板名，如 技术调查措施请示")
        self.btn_save = QPushButton("保存为模板")
        self.btn_save.clicked.connect(self._on_save)
        bottom.addWidget(QLabel("模板名:"))
        bottom.addWidget(self.name_edit)
        bottom.addWidget(self.btn_save)
        outer.addLayout(bottom)

    # ---------------- 载入 ----------------
    def _on_open(self):
        path, _ = QFileDialog.getOpenFileName(self, "选择脱密历史件", "", "Word 文档 (*.docx)")
        if not path:
            return
        try:
            text = self.load_docx(path)
        except Exception as e:
            QMessageBox.critical(self, "读取失败", str(e))
            return
        self.editor.setPlainText(self._rough_split(text))

    @staticmethod
    def load_docx(path):
        """读取 docx 全部段落纯文本。
        >>> TODO(合并时): 若要支持 .doc/.wps，先用软件现有 converter 转 docx。"""
        from docx import Document
        doc = Document(path)
        return "\n".join(p.text for p in doc.paragraphs)

    @staticmethod
    def _rough_split(text):
        """粗切结构：首个非空行标为标题；其余按行保留。
        >>> TODO(合并时，可选): 用现有 analyzer 的段落标注替换此处以获得更准的层级。"""
        lines = [l.rstrip() for l in text.splitlines()]
        out, title_done = [], False
        for l in lines:
            if not l.strip():
                continue
            if not title_done:
                out.append("标题: " + l.strip())
                title_done = True
            else:
                out.append(l)
        return "\n".join(out)

    # ---------------- 挖空 ----------------
    def _on_make_hole(self):
        cursor = self.editor.textCursor()
        selected = cursor.selectedText().strip()
        if not selected:
            QMessageBox.information(self, "提示", "请先在正文中选中要挖空的文字")
            return
        field, ok = QInputDialog.getText(self, "命名字段",
            f"把「{selected}」变成占位符，字段名：")
        field = field.strip()
        if not ok or not field:
            return
        # 把全文中所有相同文字一并替换（如所有"张某某"→{{嫌疑人}}）
        full = self.editor.toPlainText()
        placeholder = "{{" + field + "}}"
        new_full = full.replace(selected, placeholder)
        self.editor.setPlainText(new_full)
        if field not in self.field_names:
            self.field_names.append(field)
        QMessageBox.information(self, "已挖空",
            f"已把所有「{selected}」替换为 {placeholder}")

    def _on_mark_title(self):
        cursor = self.editor.textCursor()
        cursor.select(QTextCursor.LineUnderCursor)
        line = cursor.selectedText().strip()
        if not line:
            return
        if line.startswith("标题:") or line.startswith("标题："):
            return
        cursor.insertText("标题: " + line)

    # ---------------- 保存 ----------------
    def _on_save(self):
        name = self.name_edit.text().strip()
        if not name:
            QMessageBox.warning(self, "提示", "请填写模板名")
            return
        body = self.editor.toPlainText().strip()
        if not body:
            QMessageBox.warning(self, "提示", "正文为空")
            return

        parts = [body, "", "---META---"]
        parts.append("落款单位: " + (self.sender_edit.text().strip() or "{{办案单位}}"))
        parts.append("落款日期: " + (self.date_edit.text().strip() or "{{落款日期}}"))
        content = "\n".join(parts) + "\n"

        os.makedirs(TEMPLATE_DIR, exist_ok=True)
        safe = "".join(c for c in name if c not in r'\/:*?"<>|')
        path = os.path.join(TEMPLATE_DIR, safe + ".md")
        if os.path.exists(path):
            if QMessageBox.question(self, "已存在",
                f"{safe}.md 已存在，覆盖吗？",
                QMessageBox.Yes | QMessageBox.No) == QMessageBox.No:
                return
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)

        fields = re.findall(r"\{\{\s*([^}]+?)\s*\}\}", content)
        QMessageBox.information(self, "已保存",
            f"模板已存至：\n{path}\n\n包含占位符：{'、'.join(sorted(set(fields))) or '（无）'}\n"
            f"现在可到「模板起草」页选用它。")
