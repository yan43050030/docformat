# -*- coding: utf-8 -*-
"""
============================================================================
模块一：模板起草页 (TemplateDraftPage)
============================================================================

【用途】
给 docformat-qt 增加"起草"能力。现有软件是"你已经写好正文 → 我帮你排版"，
本模块补上前一环："你还没写 → 选文书类型 → 填字段 → 生成正文初稿"。
生成的初稿直接交给现有排版引擎排版，形成完整闭环：
    选类型 → 填字段起草 → 复用现有引擎排版 → 规范公文

【集成方式 —— 请把下面几点转告合并用的大模型】

1) 这是 docformat-qt 侧边栏的"第五个模式"。现有四种模式是
   智能一键处理 / 格式诊断 / 标点修复 / AI粘贴生成。
   请仿照现有某个 Page 类（如 AI 粘贴生成页）被主窗口加入侧边栏的方式，
   把 TemplateDraftPage 注册为第五个页面，标签名建议"模板起草"。
   >>> TODO(合并时): 找到主窗口里侧边栏页面注册的代码，按同样方式加入本页。

2) 生成初稿后如何排版：本页生成的是"结构化正文文本"，应交给现有排版引擎。
   README 说排版引擎在 docformat-qt/scripts/（formatter/analyzer 等）。
   >>> TODO(合并时): 把 _on_generate() 里标注 [对接排版引擎] 处，
       改成调用现有 formatter 的排版函数（传入 self._build_plain_text()）。
       若现有引擎接受 .docx 或纯文本，按其签名调整。
       在拿到确切函数名前，本页默认走内置的极简 docx 输出（build_docx_fallback），
       保证独立可跑、合并前就能测试。

3) 模板文件存放：沿用软件已有的模板目录约定。本模块用纯文本 .md 模板
   （人可直接编辑，脱密单机上数据不锁死）。
   >>> TODO(合并时): 把 TEMPLATE_DIR 改成软件实际的模板目录；
       若软件用 JSON 模板体系，也可让本页读取 JSON，把其中"正文骨架"
       字段喂给 parse_template。md 与 JSON 可并存。

4) 依赖：PyQt5（软件已用）。docx 兜底输出用 python-docx，
   若最终改为调用现有引擎排版，可不依赖 python-docx。

【模板格式】见文件末尾 TEMPLATE_FORMAT_DOC 常量，或另一个模块生成的模板。
============================================================================
"""
import os
import re

from PyQt5.QtWidgets import (
    QWidget, QListWidget, QListWidgetItem, QLineEdit, QTextEdit,
    QPushButton, QLabel, QFormLayout, QVBoxLayout, QScrollArea,
    QMessageBox, QSplitter, QPlainTextEdit
)
from PyQt5.QtCore import Qt

# >>> TODO(合并时): 改成软件实际的模板目录
TEMPLATE_DIR = os.path.join(os.path.dirname(__file__), "templates")

PLACEHOLDER_RE = re.compile(r"\{\{\s*([^}]+?)\s*\}\}")


# ---------------------------------------------------------------------------
# 模板解析（与模块二共用同一套格式约定，可抽成公共文件 template_common.py）
# ---------------------------------------------------------------------------
def extract_fields(template_text):
    """按出现顺序提取去重后的占位符字段名"""
    seen = []
    for m in PLACEHOLDER_RE.finditer(template_text):
        name = m.group(1).strip()
        if name not in seen:
            seen.append(name)
    return seen


def parse_template(template_text):
    """解析模板 → {'title', 'body':[{'type','text'}], 'meta':{}}"""
    body_part, meta = template_text, {}
    if "---META---" in template_text:
        body_part, meta_part = template_text.split("---META---", 1)
        for line in meta_part.strip().splitlines():
            if ":" in line or "：" in line:
                k, v = re.split(r"[:：]", line, 1)
                meta[k.strip()] = v.strip()
    title, body = "", []
    for line in body_part.strip().splitlines():
        s = line.strip()
        if not s:
            continue
        if s.startswith("标题:") or s.startswith("标题："):
            title = re.split(r"[:：]", s, 1)[1].strip()
        elif re.match(r"^[一二三四五六七八九十]+、", s):
            body.append({"type": "h1", "text": s})
        elif re.match(r"^（[一二三四五六七八九十]+）", s):
            body.append({"type": "h2", "text": s})
        else:
            body.append({"type": "body", "text": s})
    return {"title": title, "body": body, "meta": meta}


def render(parsed, values):
    """替换占位符；未填的保留 {{字段}} 原样，便于漏项检查"""
    def sub(text):
        return PLACEHOLDER_RE.sub(
            lambda m: values.get(m.group(1).strip()) or "{{" + m.group(1).strip() + "}}",
            text)
    return {
        "title": sub(parsed["title"]),
        "body": [{"type": b["type"], "text": sub(b["text"])} for b in parsed["body"]],
        "meta": {k: sub(v) for k, v in parsed["meta"].items()},
    }


def find_unfilled(rendered):
    remaining = set(PLACEHOLDER_RE.findall(rendered["title"]))
    for b in rendered["body"]:
        remaining |= set(PLACEHOLDER_RE.findall(b["text"]))
    return sorted(x.strip() for x in remaining)


# ---------------------------------------------------------------------------
# 页面
# ---------------------------------------------------------------------------
class TemplateDraftPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.current_template_text = ""
        self.field_inputs = {}
        self._build_ui()
        self._load_template_list()

    def _build_ui(self):
        splitter = QSplitter(Qt.Horizontal)

        left = QWidget()
        lv = QVBoxLayout(left)
        lv.addWidget(QLabel("文书类型"))
        self.list_widget = QListWidget()
        self.list_widget.currentItemChanged.connect(self._on_select_template)
        lv.addWidget(self.list_widget)
        splitter.addWidget(left)

        mid = QWidget()
        mv = QVBoxLayout(mid)
        mv.addWidget(QLabel("填写字段"))
        self.form_scroll = QScrollArea()
        self.form_scroll.setWidgetResizable(True)
        self.form_container = QWidget()
        self.form_layout = QFormLayout(self.form_container)
        self.form_scroll.setWidget(self.form_container)
        mv.addWidget(self.form_scroll)
        self.gen_btn = QPushButton("生成初稿并排版")
        self.gen_btn.clicked.connect(self._on_generate)
        mv.addWidget(self.gen_btn)
        splitter.addWidget(mid)

        right = QWidget()
        rv = QVBoxLayout(right)
        rv.addWidget(QLabel("正文预览（未填项显示 {{}}）"))
        self.preview = QPlainTextEdit()
        self.preview.setReadOnly(True)
        rv.addWidget(self.preview)
        splitter.addWidget(right)

        splitter.setSizes([200, 400, 400])
        outer = QVBoxLayout(self)
        outer.addWidget(splitter)

    def _load_template_list(self):
        self.list_widget.clear()
        if not os.path.isdir(TEMPLATE_DIR):
            return
        for fn in sorted(os.listdir(TEMPLATE_DIR)):
            if fn.endswith(".md"):
                it = QListWidgetItem(fn[:-3])
                it.setData(Qt.UserRole, os.path.join(TEMPLATE_DIR, fn))
                self.list_widget.addItem(it)

    def _on_select_template(self, current, _prev):
        if current is None:
            return
        with open(current.data(Qt.UserRole), encoding="utf-8") as f:
            self.current_template_text = f.read()
        self._rebuild_form()

    def _rebuild_form(self):
        while self.form_layout.rowCount():
            self.form_layout.removeRow(0)
        self.field_inputs.clear()
        for name in extract_fields(self.current_template_text):
            if any(k in name for k in ("情况", "说明", "内容", "简要", "事实")):
                w = QTextEdit()
                w.setFixedHeight(60)
                w.textChanged.connect(self._update_preview)
            else:
                w = QLineEdit()
                w.textChanged.connect(self._update_preview)
            self.field_inputs[name] = w
            self.form_layout.addRow(name + "：", w)
        self._update_preview()

    def _collect_values(self):
        vals = {}
        for name, w in self.field_inputs.items():
            vals[name] = (w.toPlainText() if isinstance(w, QTextEdit) else w.text()).strip()
        return vals

    def _current_rendered(self):
        return render(parse_template(self.current_template_text), self._collect_values())

    def _update_preview(self):
        if not self.current_template_text:
            return
        self.preview.setPlainText(self._build_plain_text(self._current_rendered()))

    @staticmethod
    def _build_plain_text(rendered):
        lines = [rendered["title"], ""]
        lines += [b["text"] for b in rendered["body"]]
        if rendered["meta"].get("落款单位"):
            lines += ["", rendered["meta"]["落款单位"]]
        if rendered["meta"].get("落款日期"):
            lines.append(rendered["meta"]["落款日期"])
        return "\n".join(lines)

    def _on_generate(self):
        if not self.current_template_text:
            QMessageBox.warning(self, "提示", "请先选择文书类型")
            return
        rendered = self._current_rendered()
        unfilled = find_unfilled(rendered)
        if unfilled:
            if QMessageBox.question(
                self, "存在未填字段",
                "未填写：\n" + "、".join(unfilled) + "\n\n仍要生成吗？",
                QMessageBox.Yes | QMessageBox.No) == QMessageBox.No:
                return

        plain = self._build_plain_text(rendered)

        # ============ [对接排版引擎] ============
        # >>> TODO(合并时): 把下面这段换成调用现有 formatter 排版。
        #     现有引擎若接受纯文本/Markdown，直接传 plain；
        #     若接受 .docx，先用 build_docx_fallback 出 docx 再交给引擎。
        #     现在默认走兜底 docx，保证合并前独立可测。
        try:
            out = build_docx_fallback(rendered)
            QMessageBox.information(self, "完成",
                f"已生成初稿：\n{out}\n\n（合并后此处应改为调用现有排版引擎）")
        except Exception as e:
            QMessageBox.critical(self, "生成失败", str(e))
        # =======================================


# ---------------------------------------------------------------------------
# 兜底 docx 输出：仅供合并前独立测试。合并后应删除，改用现有排版引擎。
# ---------------------------------------------------------------------------
def build_docx_fallback(rendered, out_dir=None):
    from docx import Document
    from docx.shared import Pt, Cm, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
    from docx.oxml.ns import qn

    FONTS = {"title": "方正小标宋简体", "h1": "黑体", "h2": "楷体_GB2312", "body": "仿宋"}

    def setfont(run, name, size, bold=False):
        run.font.name = name
        run.font.size = Pt(size)
        run.font.bold = bold
        run.font.color.rgb = RGBColor(0, 0, 0)
        rpr = run._element.get_or_add_rPr()
        rf = rpr.find(qn('w:rFonts'))
        if rf is None:
            rf = rpr.makeelement(qn('w:rFonts'), {}); rpr.append(rf)
        for a in ('w:eastAsia', 'w:ascii', 'w:hAnsi'):
            rf.set(qn(a), name)

    def pf(p, align=None, indent=True):
        f = p.paragraph_format
        f.line_spacing_rule = WD_LINE_SPACING.EXACTLY
        f.line_spacing = Pt(28); f.space_before = Pt(0); f.space_after = Pt(0)
        if align is not None:
            p.alignment = align
        if indent:
            f.first_line_indent = Pt(32)

    doc = Document()
    s = doc.sections[0]
    s.top_margin, s.bottom_margin = Cm(3.7), Cm(3.5)
    s.left_margin, s.right_margin = Cm(2.8), Cm(2.6)

    p = doc.add_paragraph(); pf(p, WD_ALIGN_PARAGRAPH.CENTER, indent=False)
    p.paragraph_format.space_after = Pt(16)
    setfont(p.add_run(rendered["title"]), FONTS["title"], 22)

    for b in rendered["body"]:
        p = doc.add_paragraph(); pf(p, indent=True)
        setfont(p.add_run(b["text"]), FONTS.get(b["type"], FONTS["body"]), 16)

    meta = rendered["meta"]
    if meta.get("落款单位") or meta.get("落款日期"):
        doc.add_paragraph()
        for key in ("落款单位", "落款日期"):
            if meta.get(key):
                p = doc.add_paragraph(); pf(p, WD_ALIGN_PARAGRAPH.RIGHT, indent=False)
                setfont(p.add_run(meta[key]), FONTS["body"], 16)

    out_dir = out_dir or os.path.join(os.path.dirname(__file__), "output")
    os.makedirs(out_dir, exist_ok=True)
    safe = "".join(c for c in (rendered["title"] or "未命名") if c not in r'\/:*?"<>|')
    path = os.path.join(out_dir, safe + ".docx")
    doc.save(path)
    return path


TEMPLATE_FORMAT_DOC = """
模板文件格式（.md，纯文本，人可直接编辑）：

    标题: 关于对{{犯罪嫌疑人}}采取技术调查措施的请示

    {{审批机关}}：
    一、案件基本情况
    {{案件情况}}
    二、请求事项
    现请求批准。

    ---META---
    落款单位: {{办案单位}}
    落款日期: {{落款日期}}

规则：{{字段}} 为占位符；"一、"开头识别为一级标题，"（一）"为二级标题，
其余为正文；"---META---" 之后写落款。软件启动自动扫描 TEMPLATE_DIR。
"""
